
<?php $__env->startSection('content'); ?>	

	<section id="cart_items">
			<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item active" aria-current="page">Giỏ hàng</li>
  </ol>

			<div class="table-responsive cart_info">
				<?php if(session()->has('message')): ?>
					<div class="alert alert-success"><?php echo session()->get('message'); ?></div>
				<?php elseif(session()->has('error')): ?>
					<div class="alert alert-danger"><?php echo session()->get('error'); ?></div>
				<?php endif; ?>
	
				<table class="table table-condensed">	
					<thead>
						<tr class="cart_menu">
							<td class="image">Hình ảnh</td>
							<td class="name">Tên sản phẩm</td>
							<td class="price">Giá</td>
							<td class="quantity">Số lượng</td>
							<td class="total">Thành tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>

					<form action="<?php echo e(url('/update-cart-ajax')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>


					<?php if(Session::get('cart')==true): ?>
						<?php
							$total = 0;
						?>

						<?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php
								$subtotal = $cart['product_price']*$cart['product_qty'];
								$total+=$subtotal;
							?>

						<tr>
							<td class="cart_product">
								<a href=""><img src="<?php echo e(asset('public/uploads/product/'.$cart['product_image'])); ?>" width="70" height="80" alt="<?php echo e($cart['product_name']); ?>"></a>
							</td>
							<td class="cart_description">
								<h4><?php echo e($cart['product_name']); ?></h4>
								<p><span>Mã sp: <?php echo e($cart['product_id']); ?></span><br>
								<span>Còn: <?php echo e($cart['product_quantity']); ?> sp</span></p>
							</td>
							<td class="cart_price">
								<p><?php echo e(number_format($cart['product_price'],0,',','.')); ?> VND</p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<?php
									if ($cart['product_quantity']>$cart['product_qty']) {
									?>
									<input class="cart_quantity" type="number" min="1" max="<?php echo e($cart['product_quantity']); ?>" name="cart_qty[<?php echo e($cart['session_id']); ?>]" size="2"
									value="<?php echo e($cart['product_qty']); ?>" >	
									<?php
									}else{
									?>
									<input class="cart_quantity" type="number" min="1" max="<?php echo e($cart['product_quantity']); ?>" name="cart_qty[<?php echo e($cart['session_id']); ?>]" size="2"
									value="<?php echo e($cart['product_quantity']); ?>" >	
									<?php
									}
									?>
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price">
									<?php echo e(number_format($subtotal,0,',','.')); ?> VND
								</p>
							</td>
							<td class="cart_delete">
								<a class="cart_quantity_delete" href="<?php echo e(url('/delete-cart-ajax/'.$cart['session_id'])); ?>"><i class="fa fa-times"></i></a>
							</td>
						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						<tr>
							<td colspan="3">
								<input type="submit" class="btn btn-defaul check_out" value="Cập nhật giỏ hàng" name="update_qty" >	
								<a href="<?php echo e(url('/delete-all-cart-ajax')); ?>" class="btn btn-default check_out"> Xóa tất cả sản phẩm</a>
								<?php if(Session::get('coupon')): ?>
									<a href="<?php echo e(url('/unset-coupon')); ?>" class="btn btn-default check_out"> Xóa mã giảm giá</a>
								<?php endif; ?>

								<?php if(Session::get('customer_id')): ?>
									<a class="btn btn-default check_out" href="<?php echo e(url('/checkout')); ?>">Đặt hàng</a>
								<?php else: ?>
									<a class="btn btn-default check_out" href="<?php echo e(url('/login-checkout')); ?>">Đăng nhập để đặt hàng</a>
								<?php endif; ?>

							</td>
							<td colspan="3">
								<div class="total_area">								
										<li>Tổng tiền: <span><?php echo e(number_format($total,0,',','.')); ?> VND</span></li>
										<li>Mã giảm giá: 
											<?php if(Session::get('coupon')): ?>
												<?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($cou['coupon_function']==1): ?>
														<span><?php echo e($cou['coupon_number']); ?> %</span>
															<?php
															$total_coupon =($total*$cou['coupon_number'])/100;
															echo '<li>Giảm:<span>'.number_format($total_coupon,0,',','.').' VND</span></li>';
															?>
														<li>Tiền sau khi giảm:<span> <?php echo e(number_format($total_coupon,0,',','.')); ?> VND<span></li>
													<?php elseif($cou['coupon_function']==2): ?>
														<span><?php echo e(number_format($cou['coupon_number'],0,',','.')); ?> VND</span>
															<?php
															$total_coupon =($total-$cou['coupon_number']);
															?>
														<li>Tiền sau khi giảm:<span> <?php echo e(number_format($total_coupon,0,',','.')); ?> VND</span></li>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?> 
												<span>Chưa có</span>
											<?php endif; ?>
										</li>
                        	
								</div>
							</td>	
						</tr>
					<?php else: ?>
						<tr>
							<td colspan="5"><center><h4>
								<br>Chưa có sản phẩm nào trong giỏ!<br><br><a href="<?php echo e(URL::to('/trang-chu')); ?>">Quay lại trang chủ</a>
							</h4></center></td>
						</tr>
					<?php endif; ?>
				</form>
				<br>
				<?php if(Session::get('cart')): ?>
					<form action="<?php echo e(url('/check-coupon')); ?>" method="POST">
					<?php echo csrf_field(); ?>
						<tr>
							<td colspan="2">
								<input type="text" class="form-control" name="coupon" placeholder="Nhập mã giảm giá">
								<input type="submit" class="btn btn-default check_out" name="check_coupon" value="Tính mã giảm giá">
							</td>	
						</tr>
					</form>
				<?php endif; ?>

					</tbody>
				</table>			
				
				
			</div>

	</section> <!--/#cart_items-->

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/cart/cart_ajax.blade.php ENDPATH**/ ?>