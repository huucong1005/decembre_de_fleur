
<?php $__env->startSection('admin_content'); ?>
<div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Chỉnh sửa user
                        </header>
                        <div class="panel-body">
                        
                            <div class="position-center">
                                <form role="form" enctype="multipart/form-data" action="<?php echo e(URL::to('/update-user/'.$user->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên user</label>
                                    <input type="text" name="name" class="form-control" id="exampleInputEmail1" value="<?php echo e($user->name); ?>"  required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email user</label>
                                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Nhập email" required value="<?php echo e($user->email); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Password mới</label>
                                    <input type="text" name="password" class="form-control" id="exampleInputEmail1" placeholder="Nhập password" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Số điện thoại</label>
                                    <input type="text" name="phone" class="form-control" id="exampleInputEmail1" placeholder="Nhập số điện thoại" required value="<?php echo e($user->phone); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Phân quyền</label>
                                    <select name="role_id[]" class="form-control select2_init" multiple required>
                                        <option value=""></option>

                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                        <?php echo e($rolesOfUser->contains('role_id',$role->role_id) ? 'selected' : ''); ?>

                                         value="<?php echo e($role->role_id); ?>"><?php echo e($role->role_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                
                                <button type="submit" name="update_user" class="btn btn-info">Cập nhật</button>
                                </form>
                            </div>
                        </div>
                    </section>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/user/edit_user.blade.php ENDPATH**/ ?>