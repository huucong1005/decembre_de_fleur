
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="col-sm-2"></div>
      <div class="col-sm-8"><center>Danh sách danh mục sản phẩm</center></div>
      <div class="col-sm-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-category')): ?>
        <a class="btn btn-info" href="<?php echo e(URL::to('/add-category')); ?>">Thêm danh mục</a>   
        <?php endif; ?> 
      </div>
    </div>
    <?php
      $message = Session::get('message');
      if($message){
        echo '<br><span class="text-success">'.$message.'</span>';
        Session::put('message',null);
      }
    ?>
    <form action="">
      <?php echo csrf_field(); ?>
    <div class="table-responsive"><br>
      <table class="table table-striped b-t b-light" id="dataTableList">
        <thead>
          <tr>
            
            <th>Thứ tự</th>
            <th>Tên danh mục</th>
            <th>Slug</th>
            <th>Thuộc danh mục</th>
            <th>Hiển thị</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody id="category_order">
          <?php $__currentLoopData = $list_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($category->category_id); ?>">
            
            <td><?php echo e($category->category_order); ?></td>
            <td><?php echo e($category->category_name); ?></td>
            <td><?php echo e($category->category_slug); ?></td>
            <td>
              <?php if($category->category_parent==0): ?>
                - - -
              <?php else: ?>
                <?php $__currentLoopData = $category_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if( $subItem->category_id==$category->category_parent): ?>
                    <?php echo e($subItem->category_name); ?>

                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>  
            </td>
            <td>
              <?php
              if($category->category_status==0){
              ?>
              <a href="<?php echo e(URL::to('/active-category/'.$category->category_id)); ?>"><i class="fa-eye-styling fa fa-eye-slash"></i></a>
              <?php
              }else{
              ?>
              <a href="<?php echo e(URL::to('/unactive-category/'.$category->category_id)); ?>"><i class="fa-eye-styling fa fa-eye"></i></a>
              <?php 
              }
              ?>
            </td>
            <td>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-category')): ?>
              <a href="<?php echo e(URL::to('/edit-category/'.$category->category_id)); ?>" class="active styling-icon" ui-toggle-class=""><i class="fa fa-pencil-square-o text-success text-active"></i></a>
              <?php endif; ?>
            <span style="margin: 0px 8px;"></span>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-category')): ?>
              <a href="<?php echo e(URL::to('/delete-category/'.$category->category_id)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa danh mục này ?')" ui-toggle-class=""><i class="fa fa-trash-o text-danger text"></i></a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </form>
    <footer class="panel-footer">

    </footer>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/category/list_category.blade.php ENDPATH**/ ?>