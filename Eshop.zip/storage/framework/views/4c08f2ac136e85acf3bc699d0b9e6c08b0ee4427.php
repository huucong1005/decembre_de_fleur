
<?php $__env->startSection('admin_content'); ?>
<h3>Tổng quát</h3>

<!-- //market-->
<div class="market-updates row">
	<div class="col-md-3 market-update-gd">
		<div class="market-update-block clr-block-2">
			<div class="col-md-4 market-update-right">
				<i class="fa fa-eye"> </i>
			</div>
			 <div class="col-md-8 market-update-left">
			 <h4>Khách ghé thăm</h4>
			<h3><?php echo e($visitor_this_month_count); ?></h3>
			<p>lượt truy cập/tháng này </p>
		  </div>
		  <div class="clearfix"> </div>
		</div>
	</div>
	<div class="col-md-3 market-update-gd">
		<div class="market-update-block clr-block-1">
			<div class="col-md-4 market-update-right">
				<i class="fa fa-th" ></i>
			</div>
			<div class="col-md-8 market-update-left">
			<h4>Sản phẩm</h4>
				<h3><?php echo e($product_active_count); ?>/<?php echo e($product_count); ?></h3>
				<p>đang kinh doanh</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
	<div class="col-md-3 market-update-gd">
		<div class="market-update-block clr-block-3">
			<div class="col-md-4 market-update-right">
				<i class="fa fa-usd"></i>
			</div>
			<div class="col-md-8 market-update-left">
				<h4>Bài viết</h4>
				<h3><?php echo e($post_active_count); ?>/<?php echo e($post_count); ?></h3>
				<p>đang hiển thị</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
	<div class="col-md-3 market-update-gd">
		<div class="market-update-block clr-block-4">
			<div class="col-md-4 market-update-right">
				<i class="fa fa-shopping-cart" aria-hidden="true"></i>
			</div>
			<div class="col-md-8 market-update-left">
				<h4>Đơn hàng mới</h4>
				<h3><?php echo e($new_order_count); ?></h3>
				<p>đơn chưa được xử lý</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
   <div class="clearfix"> </div>
</div>	
<!-- //market-->

<h3>Thống kê doanh số</h3>
<!-- calender-->
	<div class="row">
		<div class="panel-body">
			
				<form action="" autocomplete="off">
				<?php echo csrf_field(); ?>
					<div class="col-md-2">
						<p>Từ ngày:</p> 
						<input type="text" id="datepicker1" readonly class="form-control">
					</div>

					<div class="col-md-2">
						<p>Đến ngày:</p> 
						<input type="text" id="datepicker2" readonly class="form-control">
					</div>

					<div class="col-md-1">
						<br><input type="button" id="btn-dashboard-filter" class="btn btn-info btn-sm" value="Lọc kết quả">
					</div>
					<div class="col-md-2">
						<br><h3 style="margin-top: 4px;"><center>hay là ...</center></h3 class="mt-1">
					</div>

					<div class="col-md-2">
						<p>Lọc theo:</p>
						<select name="sort" id="sort" class="dashboard-filter form-control" >
			                <option value="">--- Chọn ---</option>
			                <option value="week"> 7 ngày qua </option>
			                <option value="lastmonth"> tháng trước </option>
			                <option value="thismonth"> tháng này </option>
			                <option value="year"> 365 ngày qua </option>
            			</select>
       					 
					</div>
					<div class="col-md-3"></div>
				</form>
				<br>

		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div id="myfirstchart" style="height: 250px;"></div>
		</div>
	</div>

<!-- calender-->


<br><h3>Thống kê truy cập</h3><br>

<div class="row">
		<div class="col-md-12">
			<table class="table table-bordered table-dark">
				<thead>
				    <tr>
				      <th scope="col">Đang online</th>
				      <th scope="col">Truy cập tháng trước</th>
				      <th scope="col">Truy cập tháng này</th>
				      <th scope="col">Truy cập năm nay</th>
				      <th scope="col">Tổng truy cập</th>
				    </tr>
				</thead>
				<tbody>
				    <tr>
				      <td><?php echo e($visitor_count); ?></td>
				      <td><?php echo e($visitor_last_month_count); ?></td>
				      <td><?php echo e($visitor_this_month_count); ?></td>
				      <td><?php echo e($visitor_year_count); ?></td>
				      <td><?php echo e($visitor_total_count); ?></td>
				      
				    </tr>
				</tbody>
			</table>
		</div>
	</div>


<br><h3>Thống kê dữ liệu</h3><br>

<div class="row">
	<div class="col-md-3 col-xs-12">
		<h4>Bộ đếm số liệu</h4>
		<div id="donut-chart"></div>
	</div>
	<div class="col-md-4 col-xs-12">
		<h4>Bài viết xem nhiều</h4>
		<ol class="list_view">
			<?php $__currentLoopData = $post_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(URL::to('/tin-tuc/'.$postItem->post_slug)); ?>" target="blank" title="<?php echo e($postItem->post_name); ?>"><?php echo e($postItem->post_name); ?> | <span style="color: black;">Lượt view:	<?php echo e($postItem->post_view); ?></span></a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ol>
	</div>
	<div class="col-md-4 col-xs-12">
		<h4>Sản phẩm xem nhiều</h4>
		<ol class="list_view">
			<?php $__currentLoopData = $product_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$productItem->product_slug)); ?>" target="blank" title="<?php echo e($productItem->product_name); ?>"><?php echo e($productItem->product_name); ?> | <span style="color: black;">Lượt view:	<?php echo e($productItem->product_view); ?></span></a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ol>
	</div>
	<div class="col-md-1 col-xs-12"></div>
</div>






		<!-- tasks -->

		<!-- //tasks -->



<script type="text/javascript">
    $(function(){
        $( "#datepicker1" ).datepicker({
            changeMonth: true,
            changeYear: true,
            prevText:"Tháng trước",
            nextText:"Tháng sau",
            dateFormat:"yy-mm-dd",
            dayNamesMin: ["T2","T3","T4","T5","T6","T7","CN"],
            duration: "slow"
        });
        $( "#datepicker2" ).datepicker({
            changeMonth: true,
            changeYear: true,
            prevText:"Tháng trước",
            nextText:"Tháng sau",
            dateFormat:"yy-mm-dd",
            dayNamesMin: ["T2","T3","T4","T5","T6","T7","CN"],
            duration: "slow"
        });

    });
</script>

<script type="text/javascript">
    $(document).ready(function(){  
        var donut = Morris.Donut({
          element: 'donut-chart',
          resize: true,
          colors: [
            '#459743',
            '#78ca76',
            '#0877f3',
            '#76b5c5',
            '#d3412c',
            '#A2349a',
            '#F38808'
          ],
          //labelColor:"#cccccc", // text color
          //backgroundColor: '#333333', // border color
          data: [
            {label:"Sản phẩm ẩn",   value:<?php echo $product_unactive_count ?>},
            {label:"Sản phẩm hiện", value:<?php echo $product_active_count ?>},
            {label:"Bài viết ẩn",   value:<?php echo $post_unactive_count ?>},
            {label:"Bài viết hiện", value:<?php echo $post_active_count ?>},
            {label:"Khách hàng",    value:<?php echo $customer_count ?>},
            {label:"Slider",        value:<?php echo $slider_count ?>},
            {label:"Đơn hàng mới",  value:<?php echo $new_order_count ?>}
          ]
        });

    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        chart30daysorder();

//morrist type: Line, Bar, Area
        var chart = new Morris.Area({
          // ID of the element in which to draw the chart.
          element: 'myfirstchart',
          // Chart data records -- each entry in this array corresponds to a point on
          // the chart.
          lineColors:['#819C79','#fc8710','#A4ADD3','#FF6541','#766B56'],

          pointFillColors:['#ffffff'],
          pointStrokeColors:['black'],

          gridTextColor:['black'],
          //set opaciti for Area type
          fillOpacity:0.2,
          hideHover:'auto',
          parseTime:false,
          smooth:false,
          resize:true,
          // The name of the data record attribute that contains x-values.
          xkey: 'period',
          // A list of names of data record attributes that contain y-values.
          ykeys: ['order','sales','profit','quantity'],
          behaveLikeLine:true,
          // Labels for the ykeys -- will be displayed when you hover over the
          labels: ['Đơn hàng','Doanh số','Lợi nhuận','Số lượng']
        });

        function chart30daysorder() {
            var _token = $('input[name="_token"]').val();
            $.ajax({
                url : '<?php echo e(url('/days-order')); ?>',
                method: 'POST',
                dataType:'JSON',
                data: {_token:_token},
                success:function(data){
                    chart.setData(data);
                } 
            });
        };

        $('.dashboard-filter').change(function() {
            var _token = $('input[name="_token"]').val();
            var dashboard_value=$(this).val();

            $.ajax({
                url : '<?php echo e(url('/dashboard-filter')); ?>',
                method: 'POST',
                dataType:'JSON',
                data: {_token:_token,dashboard_value:dashboard_value},
                success:function(data){
                    chart.setData(data);
                } 
            });
        });

        $('#btn-dashboard-filter').click(function() {
            var _token = $('input[name="_token"]').val();
            var date_from=$('#datepicker1').val();
            var date_to=$('#datepicker2').val();

            $.ajax({
                url : '<?php echo e(url('/filter-by-date')); ?>',
                method: 'POST',
                dataType:'JSON',
                data: {_token:_token,date_to:date_to,date_from:date_from},
                success:function(data){
                    chart.setData(data);
                } 
            });
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>