
<?php $__env->startSection('slider'); ?>

                    <div id="slider-carousel" class="carousel slide" data-ride="carousel">

                        <div class="carousel-inner">
                        <?php 
                            $i=0;
                        ?>
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $i++;
                        ?>
                            <div class="item <?php echo e($i==1 ? 'active' : ''); ?>">
                                <div class="col-sm-4">
                                    <p style="margin-top: 130px;"><?php echo e($slider->slider_desc); ?></p>
                                    
                                </div>
                                <div class="col-sm-8 image">
                                    <img src="public/uploads/slider/<?php echo e($slider->slider_image); ?>" class="girl img-responsive" alt="<?php echo e($slider->slider_desc); ?>" />
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                        </div>
                        <ol class="carousel-indicators">
                            <?php for($i=0; $i<$slider_count; $i++): ?>
                            <li data-target="#slider-carousel" data-slide-to="<?php echo e($i); ?>" class="<?php echo e($i==0 ? 'active' : ''); ?>"></li>
                            <?php endfor; ?>
                        </ol>
                        
                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>          
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2 class="title text-center">Liên hệ</h2>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item active" aria-current="page">Liên hệ</li>
  </ol>
</nav>
<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contactItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col-md-12">
		<h4>Thông tin liên hệ</h4>
	</div>
	<div class="col-md-7">		
		<p>Cửa hàng: <span><?php echo e($contactItem->info_name); ?></span></p>
        <p>Địa chỉ: <span><?php echo e($contactItem->info_address); ?></span></p>
		<p>Số điện thoại: <span>(+84) <?php echo e($contactItem->info_contact); ?></span></p>
		<p>Email: <a target="blank" href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&source=mailto&to=<?php echo e($contactItem->info_gmail); ?>"><?php echo e($contactItem->info_gmail); ?></a></p>
	</div>
	<div class="col-md-5">
		<?php echo $contactItem->info_fanpage; ?>

	</div>
	<div class="col-md-12">
		
		<h4>Map</h4>
		<?php echo $contactItem->info_map; ?>

	</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('partner'); ?>
<hr>
<center><h3>~ Đối tác của chúng tôi ~</h3></center>
<div class="owl-carousel owl-theme">
    <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$partnerItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item">
        <a target="_blank" href="<?php echo e($partnerItem->partner_link); ?>">
            <center><h4><?php echo e($partnerItem->partner_name); ?></h4></center>
             <img src="<?php echo e(URL::to('/public/uploads/logo/'.$partnerItem->partner_image)); ?>" alt="<?php echo e($partnerItem->partner_name); ?>" width="300" height="100" />
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/contact/contact.blade.php ENDPATH**/ ?>