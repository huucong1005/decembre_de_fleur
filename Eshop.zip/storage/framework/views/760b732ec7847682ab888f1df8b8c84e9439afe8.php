
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách đơn đặt hàng
    </div>
    <?php
      $message = Session::get('message');
      if($message){
        echo '<br><span class="text-success">'.$message.'</span>';
        Session::put('message',null);
      }
    ?>
   
    <div class="table-responsive"><br>
      <table class="table table-striped b-t b-light" id="dataTableList">
        <thead>
          <tr>
            <th>Stt</th>
            <th>Mã đơn hàng</th>
            <th>Tình trạng đơn hàng</th>
            <th>Ngày đặt hàng</th>
            <th>Ngày nhận hàng</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $i=0;
          ?>
          <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $i++;
          ?>
          <tr>
            <td><i><?php echo e($i); ?></i></td>
            <td><?php echo e($order->order_code); ?></td>
            <td><?php if($order->order_status==1): ?>
                  Đơn hàng mới
                <?php elseif($order->order_status==2): ?>
                  Đã xử lý
                <?php else: ?>
                  Hủy đơn hàng
                <?php endif; ?>
            </td>
            <td><?php echo e($order->created_at); ?></td>
            <td><?php echo e($order->shipping->shipping_date_revice); ?></td>
            <td>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-order')): ?>
              <a href="<?php echo e(URL::to('/view-order/'.$order->order_code)); ?>" class="active styling-icon" ui-toggle-class=""><i class="fa-eye-styling fa fa-eye text-success text-active"></i></a>
              <?php endif; ?>
            <span style="margin: 0px 8px;"></span>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-order')): ?>
              <a href="<?php echo e(URL::to('/delete-order/'.$order->order_code)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa danh mục này ?')" ui-toggle-class=""><i class="fa fa-trash-o text-danger text"></i></a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      
    </footer>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/order/list_order.blade.php ENDPATH**/ ?>