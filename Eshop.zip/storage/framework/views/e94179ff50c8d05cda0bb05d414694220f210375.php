<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Lấy lại mật khẩu</title>
</head>
<body>
	<p>Click vào: <?php echo e($data['body']); ?> </p>
	
</body>
</html><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/mail/send_mail_reset_password.blade.php ENDPATH**/ ?>