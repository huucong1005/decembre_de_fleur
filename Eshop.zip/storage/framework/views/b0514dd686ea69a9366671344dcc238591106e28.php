
<?php $__env->startSection('content'); ?>
	<h2 class="title text-center">Chi tiết đơn đặt hàng #<?php echo e($order_code); ?></h2>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/history-order')); ?>">Lịch sử đặt hàng</a></li>
    <li class="breadcrumb-item active" aria-current="page">Chi tiết đơn đặt hàng #<?php echo e($order_code); ?></li>
  </ol>
</nav>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading text-align-left">
      Thông tin đơn hàng
    </div>

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th>Mã đơn</th>
            <th>Tình trạng</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo e($order_code); ?></td>
            <td>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ord_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($ord_status->order_status==1): ?>
                <span class="text-info">Đơn hàng mới</span>
              <?php elseif($ord_status->order_status==2): ?>
                <span class="text-success">Đã xử lý</span>
              <?php else: ?>
                <span class="text-danger">Hủy đơn hàng</span>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading text-align-left">
      Thông tin người mua
    </div>

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th>Tên khách hàng</th>
            <th>Số điện thoại</th>
            <th>Email</th>
            <th>Ngày đặt hàng</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo e($customer->customer_name); ?></td>
            <td><?php echo e($customer->customer_phone); ?></td>
            <td><?php echo e($customer->customer_email); ?></td>
            <td><?php echo e($shipping->created_at); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
<div class="panel panel-default">
    <div class="panel-heading text-align-left">
      Thông tin vận chuyển
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th>Tên người nhận</th>
            <th>Ngày nhận</th>
            <th>Địa chỉ</th>
            <th>Số điện thoại</th>
            <th>Hình thức thanh toán</th>
            <th>Ghi chú</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo e($shipping->shipping_name); ?></td>
            <td><?php echo e($shipping->shipping_date_revice); ?></td>
            <td><?php echo e($shipping->shipping_address); ?></td>
            <td><?php echo e($shipping->shipping_phone); ?></td>
            <td><?php if($shipping->shipping_method=='direct_payment'): ?>
                  Thanh toán khi nhận hàng
                <?php elseif($shipping->shipping_method=='vnpay'): ?>
                  Thanh toán qua VN Pay
                <?php else: ?>
                  Thanh toán bằng chuyển khoản
                <?php endif; ?>
            </td>
            <td><?php echo e($shipping->shipping_notes); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading text-align-left">
      Chi tiết sản phẩm
    </div>
    <div class="table-responsive">
      <table class="table b-t b-light">
        <thead>
          <tr>
            <th>Stt</th>
            <th>Tên sản phẩm</th>
            <th>Số lượng mua</th>
            <th>Giá</th>
            <th>Tổng tiền</th> 
          </tr>
        </thead>
        <tbody>
          <?php $i=0;  $total=0; ?>
          <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
              $i++;
              $subtotal=$details->product_price*$details->product_sales_quantity;
              $total+=$subtotal
            ?>
          <tr class="color_qty_<?php echo e($details->product_id); ?>">
            <td><i><?php echo e($i); ?></i></td>
            <td><?php echo e($details->product_name); ?></td>
            <td><?php echo e($details->product_sales_quantity); ?></td>
              
            <td><?php echo e(number_format($details->product_price,0,',','.')); ?></td>
            <td><?php echo e(number_format($subtotal,0,',','.')); ?></td>
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <tr><td colspan="5"><p></p></td></tr>
          <tr class="panel-heading text-align-right">
            
            <td colspan="4">Tổng giá trị đơn hàng: </td>
            <td style="text-align: right;"><?php echo e(number_format($total,0,',','.')); ?></td>
          </tr>
          <tr class="panel-heading text-align-right">
            
            <td colspan="4">Mã coupon:  <?php
                            if($details->product_coupon!='---'){
                              echo $details->product_coupon;
                            }else{
                              echo 'Không coupon';
                            }
                            ?>
            </td>
            <td style="text-align: right;">
              <?php
                $total_coupon=0;
                if($coupon_function==1){
                  $total_after_coupon= ($total*$coupon_number)/100;
                  $total_coupon= $total-$total_after_coupon;
                  echo '- '.number_format($total_after_coupon,0,',','.');
                }elseif($coupon_function==2){
                  $total_coupon= $total-$coupon_number;
                  echo '- '.number_format($coupon_number,0,',','.');
                }
              ?>
            </td>
          </tr ><tr class="panel-heading text-align-right">
            
            <td colspan="4">Phí vận chuyển: </td>
            <td  style="text-align: right;"><?php echo e('+ '.number_format($details->product_feeship,0,',','.')); ?></td>
          </tr>
          <tr class="panel-heading text-align-right" style="font-weight: bold;">
            
            <td colspan="4">Tổng: </td>
            <td  style="text-align: right;"><?php echo e(number_format(($total_coupon+$details->product_feeship),0,',','.')); ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div><center><a href="<?php echo e(URL::to('/history-order')); ?>" class="btn btn-warning"> <i class="fa fa-arrow-left mr-4"></i>Quay lại</a></center>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/history_order/view_history_order.blade.php ENDPATH**/ ?>