
<?php $__env->startSection('admin_content'); ?>
<div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Giảm giá tất cả
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" enctype="multipart/form-data" action="<?php echo e(URL::to('/update-discount-all')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                
                                <div class="form-group">
                                    <label for="exampleInput">Nhập % giảm giá cho tất cả sản phẩm</label>
                                    <input type="number" name="discount_all"class="form-control" id="exampleInput" required value="" max="80" min="0">
                                </div>

                                <button type="submit" name="update_discount" class="btn btn-info">Cập nhật</button>
                                </form>
                            </div>

                        </div>
                    </section>

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/product/edit_discount_all.blade.php ENDPATH**/ ?>