
<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
	<?php $__currentLoopData = $post_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/tin-tuc')); ?>">Tin tức</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/danh-muc-tin-tuc/'.$item->cate_post_slug)); ?>"><?php echo e($item->cate_post_name); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($item->post_name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>
</nav>
<div class="features_items"><!--features_items-->
    	<div class="blog-post-area">
			<h2 class="title text-center">Tin tức</h2>

	<?php $__currentLoopData = $post_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="single-blog-post">
				<h2><?php echo e($detail->post_name); ?></h2>
				<h6>*<?php echo e($detail->cate_post_name); ?> <span style="margin-left: 10px;">post: #<?php echo e($detail->cate_post_id); ?> </span></h6><br>
					<img class="img-responsive center-block"  src="<?php echo e(URL::to('/public/uploads/post/'.$detail->post_image)); ?>" alt="<?php echo e($detail->post_name); ?>"><br>
				<p><?php echo $detail->post_content; ?></p> <br>

			</div>
		</div><!--/blog-post-area-->
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<h2 class="text-center">Tin tức gợi ý</h2>
	<div class="recommended_items recommended-post col-sm-12"><!--recommended_items-->
		
		<?php $__currentLoopData = $recommended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$recommendedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="post-item ">
   				<div class="item-info">
   					<a href="<?php echo e(URL::to('/tin-tuc/'.$recommendedItem->post_slug)); ?>"><img class="img-responsive center-block" style="width: 80% !important; height: 130px !important; " src="<?php echo e(URL::to('/public/uploads/post/'.$recommendedItem->post_image)); ?>" alt="<?php echo e($recommendedItem->post_name); ?>"></a>
   					<div class="post-detail">						       			
   						<h4 class="post-title"><a href="<?php echo e(URL::to('/tin-tuc/'.$recommendedItem->post_slug)); ?>"><?php echo e($recommendedItem->post_name); ?></a></h4>
   					</div>
   				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
	</div>
</div><!--/recommended_items-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/post/post_detail.blade.php ENDPATH**/ ?>