

<?php $__env->startSection('slider'); ?>

                    <div id="slider-carousel" class="carousel slide" data-ride="carousel">

                        <div class="carousel-inner">
                        <?php 
                            $i=0;
                        ?>
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $i++;
                        ?>
                            <div class="item <?php echo e($i==1 ? 'active' : ''); ?>">
                                <div class="col-sm-4">
                                    <p style="margin-top: 130px;"><?php echo e($slider->slider_desc); ?></p>
                                    
                                </div>
                                <div class="col-sm-8 image">
                                    <img src="public/uploads/slider/<?php echo e($slider->slider_image); ?>" class="girl img-responsive" alt="<?php echo e($slider->slider_desc); ?>" />
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                        </div>
                        <ol class="carousel-indicators">
                            <?php for($i=0; $i<10; $i++): ?>
                            <li data-target="#slider-carousel" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                            <?php endfor; ?>
                        </ol>
                        
                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/slider.blade.php ENDPATH**/ ?>