
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="col-sm-2"></div>
      <div class="col-sm-8"><center>Danh sách thương hiệu sản phẩm</center></div>
      <div class="col-sm-2">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-brand')): ?>
            <a class="btn btn-info" href="<?php echo e(URL::to('/add-brand')); ?>">Thêm thương hiệu</a>   
          <?php endif; ?>   
      </div>  
    </div>
    <?php
      $message = Session::get('message');
      if($message){
        echo '<br><span class="text-success">'.$message.'</span>';
        Session::put('message',null);
      }
    ?>
    <div class="table-responsive"><br>
      
      <table class="table table-striped b-t b-light" id="dataTableList">
        <thead>
          <tr>
            <th>Thứ tự</th>
            <th>Tên thương hiệu</th>
            <th>Slug</th>
            <th>Hiển thị</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody id="brand_order">
          <?php $__currentLoopData = $list_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($brand->brand_id); ?>">
            <td><?php echo e($brand->brand_order); ?></td>
            <td><?php echo e($brand->brand_name); ?></td>
            <td><?php echo e($brand->brand_slug); ?></td>
            <td>

              <?php
              if($brand->brand_status==0){
              ?>
              <a href="<?php echo e(URL::to('/active-brand/'.$brand->brand_id)); ?>"><i class="fa-eye-styling fa fa-eye-slash"></i></a>
              <?php
              }else{
              ?>
              <a href="<?php echo e(URL::to('/unactive-brand/'.$brand->brand_id)); ?>"><i class="fa-eye-styling fa fa-eye"></i></a>
              <?php 
              }
              ?>

            </td>
            <td>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-brand')): ?>
              <a href="<?php echo e(URL::to('/edit-brand/'.$brand->brand_id)); ?>" class="active styling-icon" ui-toggle-class=""><i class="fa fa-pencil-square-o text-success text-active"></i></a>
              <?php endif; ?>
              <span style="margin: 0px 8px;"></span>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-brand')): ?>
              <a href="<?php echo e(URL::to('/delete-brand/'.$brand->brand_id)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa thương hiệu này ?')" ui-toggle-class=""><i class="fa fa-trash-o text-danger text"></i></a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
   
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/brand/list_brand.blade.php ENDPATH**/ ?>