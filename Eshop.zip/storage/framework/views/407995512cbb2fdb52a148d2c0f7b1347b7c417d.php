<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Confirm order </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
	<p style="text-align: center; color: #134b5f; ">Đây là email tự động, vui lòng không phản hồi email này.</p>
	<div class="container" style="background-color: #a8d5e5; border-radius: 15px; padding: 20px;">
		<div class="col-md-12">
			<div class="col-md-6" style="text-align: center;   font-weight: bold;font-size: 30px;">
				<h4 style="margin: 0;"> Cửa hàng hoa tươi tháng 12</h4>
				<h6 style="margin: 0;"> Thông báo đơn đặt hàng</h6>
			</div>

			<div class="col-md-6 logo"  >
				<p style="font-size: 17px;">
					Chào bạn: <strong style="color: #000; text-decoration: inherit;"><?php echo e($shipping_array['customer_name']); ?></strong>, 
					<span  >Bạn hoặc một ai đó đã đặt hàng với thông tin như sau </span>
				</p>
			</div>

			<div class="col-md-12">
				<h4  style=" text-transform: uppercase;">Thông tin đơn hàng</h4>
				<p  >Mã đơn: #<strong  style="text-transform: uppercase;"><?php echo e($code['order_code']); ?></strong></p>
				<p  >Mã khuyến mại: <strong  style="text-transform: uppercase;"><?php echo e($code['coupon_code']); ?></strong></p>
				<p  >Dịch vụ: <strong  style="text-transform: uppercase;">Đặt hoa trực tuyến</strong></p><br>

				<h4  style=" text-transform: uppercase;">Thông tin nhận hàng</h4>
				<p  >Email: 
					<?php if($shipping_array['shipping_email']==''): ?>
						Không có
					<?php else: ?>
						<span  ><?php echo e($shipping_array['shipping_email']); ?></span>
					<?php endif; ?>
				</p>
				<p  >Người nhận: 
					<?php if($shipping_array['shipping_name']==''): ?>
						Không có
					<?php else: ?>
						<span><?php echo e($shipping_array['shipping_name']); ?></span>
					<?php endif; ?>
				</p>
				<p   >Địa chỉ nhận hàng: 
					<?php if($shipping_array['shipping_address']==''): ?>
						Không có
					<?php else: ?>
						<span><?php echo e($shipping_array['shipping_address']); ?></span>
					<?php endif; ?>
				</p>
				<p  >Số điện thoại:
					<?php if($shipping_array['shipping_phone']==''): ?>
						Không có
					<?php else: ?>
						<span><?php echo e($shipping_array['shipping_phone']); ?></span>
					<?php endif; ?>
				</p>
				<p   >Ghi chú: 
					<?php if($shipping_array['shipping_notes']==''): ?>
						Không có
					<?php else: ?>
						<span><?php echo e($shipping_array['shipping_notes']); ?></span>
					<?php endif; ?>
				</p>
				<p  >Phương thức thanh toán: 
					<?php if($shipping_array['shipping_method']=='direct_payment'): ?>
						<span>Thanh toán khi nhận hàng</span>
					<?php elseif($shipping_array['shipping_method']=='transfer_money'): ?>
						<span>Chuyển khoản ngân hàng</span>
					<?php else: ?>
						<span>thanh toán qua Paypal</span>
					<?php endif; ?>
				</p><br>

				
				<h4  style=" text-transform: uppercase;">Sản phẩm đã đặt</h4>
				<table class="table-bodered" style="border: 1px;">
		            <thead>
		                <tr>
		                    <th style="padding: 3px 20px 3px 10px;">Tên sản phẩm</th>
		                    <th style="padding: 3px 20px 3px 10px;">Số lượng</th>
		                    <th style="padding: 3px 20px 3px 10px;">Giá</th>
		                </tr>
		            </thead>
		            <tbody>
		            	<?php $__currentLoopData = $cart_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              				<tr>
              					<td><?php echo e($cart['product_name']); ?></td>
              					<td><?php echo e($cart['product_qty']); ?></td>
              					<td><?php echo e(number_format($cart['product_price'],0,',','.')); ?> vnd</td>
              				</tr>
		            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		            </tbody>	
		        </table>	<br>
		        <p  >Nếu thông tin nhận hàng không đúng, hãy liên hệ với chúng tôi ngay khi bạn nhận ra.</p><br>
	
			</div>
		</div>
	</div>



	<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/mail/confirm_order.blade.php ENDPATH**/ ?>