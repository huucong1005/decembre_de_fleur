
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $brand_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($brand_name->brand_name); ?></li>
  </ol>
</nav>
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Thương hiệu: <?php echo e($brand_name->brand_name); ?></h2>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
    <div class="col-md-5">
        <form class="form" >
        <?php echo csrf_field(); ?>
        <label for="amount">Lọc theo: </label>
            <select name="sort" id="sort" class="form-control" style="width: 85%; margin-top: 4px;">
                <option value="<?php echo e(Request::url()); ?>?sort_by=none">--- Mặc định ---</option>
                <option value="<?php echo e(Request::url()); ?>?sort_by=tang_dan"> Giá tăng dần </option>
                <option value="<?php echo e(Request::url()); ?>?sort_by=giam_dan"> Giá giảm dần </option>
                <option value="<?php echo e(Request::url()); ?>?sort_by=kytu_az"> Từ a -> z </option>
                <option value="<?php echo e(Request::url()); ?>?sort_by=kytu_za"> Từ z -> a </option>
            </select>
        </form>
    </div>

    <div class="col-md-7">
    <form class="form" > 
    <p>   
        <label for="amount">Price range:</label>
        <input size="25" type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;"> 
        <input type="hidden" id="start_price" name="start_price"> 
        <input type="hidden" id="end_price" name="end_price"> 
     </p>
     <div>
        <div class="pull-left" id="slider-range" style="width: 70%; margin-top: 6px;"></div>
        <input type="submit" style="width: 15%; margin-left: 10px; margin-top: -5px;" value="Lọc giá" class="btn btn-default">
    </div>       
        
        
    </form>
    </div>
</div>   <br> 

<?php $__currentLoopData = $brand_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($product->deleted_at==NULL): ?>
    <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_slug)); ?>">
        <div class="col-sm-4">
        <div class="product-image-wrapper">
            <div class="single-products">
                    <div class="productinfo text-center">
                    <form>
                    <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($product->product_id); ?>" class="cart_product_id_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_name); ?>" class="cart_product_name_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_quantity); ?>" class="cart_product_quantity_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_image); ?>" class="cart_product_image_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_cost); ?>" class="cart_product_cost_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_price); ?>" class="cart_product_price_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_discount); ?>" class="cart_product_discount_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="1" class="cart_product_qty_<?php echo e($product->product_id); ?>">

                        <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_slug)); ?>">
                            <img src="<?php echo e(URL::to('/public/uploads/product/'.$product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="240" height="350" /><br><br>
                            <p style="font-size: 16px; text-transform: uppercase;"><?php echo e($product->product_name); ?></p>
                        <?php if($product->product_discount==0): ?>
                            <br>
                            <h2><?php echo e(number_format($product->product_price).' '.'VND'); ?></h2>
                        <?php else: ?>
                            <p>Giảm: <?php echo e($product->product_discount); ?>% <span style="margin-left: 10px;"></span> <del><?php echo e(number_format($product->product_price).' '.'VND'); ?></del></p>
                            <h2><?php echo e(number_format($product->product_price - (($product->product_price*$product->product_discount)/100)).' '.'VND'); ?></h2>
                            <img src="<?php echo e(URL::to('/public/uploads/logo/sale.png')); ?>" class="new" >
                        <?php endif; ?>
                            
                        </a> 
                        <button type="button" class="btn btn-default add-to-cart" name="add-to-cart" data-id_product="<?php echo e($product->product_id); ?>"><i class="fa fa-shopping-cart"></i>Thêm vào giỏ hàng</button>
                    </form>
                    </div>

                    
            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    <li><a href="#"><i class="fa fa-plus-square"></i>Yêu thích</a></li>
                    <li><a href="#"><i class="fa fa-plus-square"></i>So sánh</a></li>
                </ul>
            </div>
        </div>
    </div>
    </a>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--features_items-->





    <div class="pagination pagination-sm m-t-none m-b-none">
           <?php echo e($brand_by_id->links("pagination::bootstrap-4")); ?>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/brand/show_brand_product.blade.php ENDPATH**/ ?>