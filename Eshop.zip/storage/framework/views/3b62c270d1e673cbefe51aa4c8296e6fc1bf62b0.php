
<?php $__env->startSection('admin_content'); ?>
<div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Cập nhật bài viết
                        </header>
                        <?php
                            $message = Session::get('message');
                            if($message){
                                echo '<br><span class="text-success">'.$message.'</span>';
                                Session::put('message',null);
                            }
                        ?>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" enctype="multipart/form-data" action="<?php echo e(URL::to('/update-post/'.$post->post_id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInput">Tên bài viết</label>
                                    <input type="text" data-validation="length" data-validation-length="min3" data-validation-error-msg="Phải điền ít nhất 3 kí tự"  name="post_name" class="form-control" placeholder="Tên sản phẩm" required id="slug" onkeyup="ChangeToSlug();"  value="<?php echo e($post->post_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Slug</label>
                                    <input type="text" name="post_slug" class="form-control " id="convert_slug" placeholder="slug" value="<?php echo e($post->post_slug); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Hình ảnh bài viết</label>
                                    <input type="file" name="post_image" class="form-control" id="exampleInput" >
                                    <img src="<?php echo e(URL::to('public/uploads/post/'.$post->post_image)); ?>" height="120" width="200">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Mô tả bài viết</label>
                                    <textarea style="resize: none" rows="3" class="form-control" name="post_desc" id="ckeditor7" placeholder="Mô tả"><?php echo e($post->post_desc); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Nội dung bài viết</label>
                                    <textarea style="resize: none" rows="6" class="form-control" name="post_content" id="ckeditor8" placeholder="Mô tả"><?php echo e($post->post_content); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Danh mục bài viết</label>
                                    <select name="cate_post_id" class="form-control m-bot15">
                                    <?php $__currentLoopData = $category_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $catePostItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                     
                                        <option <?php echo e($post->cate_post_id==$catePostItem->cate_post_id ? 'selected' : ''); ?> value="<?php echo e($catePostItem->cate_post_id); ?>"><?php echo e($catePostItem->cate_post_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </select>
                                </div>
                                <button type="submit" name="update_post" class="btn btn-info">Cập nhật</button>
                                </form>
                            </div>

                        </div>
                    </section>

            </div>
<script src="<?php echo e(asset('public/backend/ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript">
    CKEDITOR.replace('ckeditor7',{
        filebrowserImageUploadUrl:"<?php echo e(url('uploads-ckeditor?_token='.csrf_token())); ?>",
        filebrowserBrowseUrl:"<?php echo e(url('file-browser?_token='.csrf_token())); ?>",
        filebrowserUploadMethod:'form'
    });
    CKEDITOR.replace('ckeditor8',{
        filebrowserImageUploadUrl:"<?php echo e(url('uploads-ckeditor?_token='.csrf_token())); ?>",
        filebrowserBrowseUrl:"<?php echo e(url('file-browser?_token='.csrf_token())); ?>",
        filebrowserUploadMethod:'form'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/post/edit_post.blade.php ENDPATH**/ ?>