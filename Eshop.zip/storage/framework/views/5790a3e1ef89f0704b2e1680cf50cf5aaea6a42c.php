<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Thư từ: <?php echo e($name); ?></h1>
	<h4>với nội dung: <?php echo e($body); ?></h4>
	
</body>
</html><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/mail/send_mail.blade.php ENDPATH**/ ?>