
<?php $__env->startSection('admin_content'); ?>
<div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Chỉnh sửa danh mục sản phẩm
                        </header>
                        <div class="panel-body">
                        <?php $__currentLoopData = $edit_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="position-center">
                                <form role="form" action="<?php echo e(URL::to('/update-category/'.$edit_value->category_id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên danh mục</label>
                                    <input type="text" name="category_name" class="form-control" id="exampleInputEmail1" value="<?php echo e($edit_value->category_name); ?>"  required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Mô tả</label>
                                    <textarea style="resize: none" rows="6" class="form-control" name="category_desc" id="exampleInputPassword1" ><?php echo e($edit_value->category_desc); ?></textarea>
                                </div>

                                <button type="submit" name="update_category" class="btn btn-info">cập nhật</button>
                            	</form>
                        	</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/edit_category.blade.php ENDPATH**/ ?>