
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="col-sm-2">
        
      </div>
      <div class="col-sm-8"><center>Danh sách mã giảm giá</center></div>
      <div class="col-sm-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-coupon')): ?>
          <a class="btn btn-info" href="<?php echo e(URL::to('/add-coupon')); ?> ">Thêm Coupon</a>      
        <?php endif; ?> 
      </div>
    </div>
    <?php
      $message = Session::get('message');
      if($message){
        echo '<br><span class="text-success">'.$message.'</span>';
        Session::put('message',null);
      }
    ?>
    <div class="table-responsive"><br>
      <table class="table table-striped b-t b-light" id="dataTableList">
        <thead>
          <tr>
            
            <th>Tên mã</th>
            <th>Mã giảm giá</th>
            <th>Số lượng mã</th>
            <th>Loại mã giảm</th>
            <th>Số giảm</th>
            <th>Ngày bắt đầu</th>
            <th>Ngày kết thúc</th>
            <th>Tình trạng</th>
            <th>Hết hạn</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $all_coupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
            <td>
              <?php echo e($coupon->coupon_name); ?><p style="margin-top: 10px;"></p>
              <?php if($coupon->coupon_status==1 && $coupon->coupon_quantity>0 && $coupon->coupon_end>$now): ?>
                <a class="btn btn-default btn-xs" href="<?php echo e(URL::to('/send-coupon',[
                  'coupon_quantity'=>$coupon->coupon_quantity,
                  'coupon_code'=>$coupon->coupon_code,
                  'coupon_number'=>$coupon->coupon_number,
                  'coupon_function'=>$coupon->coupon_function
                ])); ?>">Gửi email <br>cho khách</a>
              <?php endif; ?>
            </td>
            <td><?php echo e($coupon->coupon_code); ?></td>
            <td><?php echo e($coupon->coupon_quantity); ?></td>

            <td>
              <?php   if($coupon->coupon_function==1){    ?>
              Giảm theo %
              <?php   }else{    ?>
              Giảm theo tiền
              <?php   }         ?>
            </td>

            <td>
              <?php   if($coupon->coupon_function==1){    ?>
              Giảm <?php echo e($coupon->coupon_number); ?> %
              <?php   }else{    ?>
              Giảm <?php echo e($coupon->coupon_number); ?> VND
              <?php   }         ?>
            </td>
            <td><?php echo e($coupon->coupon_start); ?></td>
            <td><?php echo e($coupon->coupon_end); ?></td>
            <td>
              <?php
              if($coupon->coupon_status==0){
              ?>
              <a href="<?php echo e(URL::to('/active-coupon/'.$coupon->coupon_id)); ?>"><i class="fa-eye-styling fa fa-lock"></i></a>
              <?php
              }else{
              ?>
              <a href="<?php echo e(URL::to('/unactive-coupon/'.$coupon->coupon_id)); ?>"><i class="fa-eye-styling fa fa-unlock"></i></a>
              <?php 
              }
              ?>
            </td>
            <td>
              
                <?php if($coupon->coupon_end>=$now): ?>
                  <p style="color: green;">còn hạn</p>
                <?php else: ?>
                  <p style="color: red;">hết hạn</p>
                <?php endif; ?>
               
            </td>
            <td>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-coupon')): ?>
              <a href="<?php echo e(URL::to('/delete-coupon/'.$coupon->coupon_id)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa mã này ?')" ui-toggle-class=""><i class="fa fa-trash-o text-danger text"></i></a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      
    </footer>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/coupon/list_coupon.blade.php ENDPATH**/ ?>