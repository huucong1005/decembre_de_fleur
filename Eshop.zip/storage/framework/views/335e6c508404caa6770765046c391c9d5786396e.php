
<?php $__env->startSection('content'); ?>	
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/login-checkout')); ?>">Đăng nhập</a></li>
    <li class="breadcrumb-item active" aria-current="page">Lấy lại mật khẩu</li>
  </ol>
</nav>
	<div class="row"><br><br><br>
		<div class="col-sm-12 ">
			<div class="login-form"><!--login form-->
				<?php if(session()->has('message')): ?>
					<div class="alert alert-success"><?php echo session()->get('message'); ?></div>
				<?php elseif(session()->has('error')): ?>
					<div class="alert alert-danger"><?php echo session()->get('error'); ?></div>
				<?php endif; ?>
				<?php
					$token =$_GET['token'];
					$email =$_GET['email'];
				?>
				<h2>Điền mật khẩu mới!</h2>
				<form action="<?php echo e(URL::to('/confirm-password')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="email" value="<?php echo e($email); ?>" />
					<input type="hidden" name="token" value="<?php echo e($token); ?>" />
					<input type="password" name="password_account"  required placeholder="New password..." />
					<center>
						<button type="submit" class="btn btn-default" style="padding: 7px 30px; border-radius: 3px; margin-top: 20px;">Xác nhận</button>
					</center>
				
			</div><!--/login form-->
		</div>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/checkout/new_password.blade.php ENDPATH**/ ?>