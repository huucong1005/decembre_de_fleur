
<?php $__env->startSection('content'); ?>	
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/login-checkout')); ?>">Đăng nhập</a></li>
    <li class="breadcrumb-item active" aria-current="page">Lấy lại mật khẩu</li>
  </ol>
</nav>
	<div class="row"><br><br><br>
		<div class="col-sm-12 ">
			<div class="login-form"><!--login form-->
				<?php if(session()->has('message')): ?>
					<div class="alert alert-success"><?php echo session()->get('message'); ?></div>
				<?php elseif(session()->has('error')): ?>
					<div class="alert alert-danger"><?php echo session()->get('error'); ?></div>
				<?php endif; ?>
				<h2>Điền email của bạn để lấy lại mật khẩu !</h2>
				<form action="<?php echo e(URL::to('/send-mail-recover-password')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input type="email" name="email_account"  required placeholder="Email" />
					<center>
						<button type="submit" class="btn btn-default" style="padding: 7px 30px; border-radius: 3px; margin-top: 20px;">Gửi</button>
					</center>
				
			</div><!--/login form-->
		</div>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/checkout/forget_password.blade.php ENDPATH**/ ?>