

<?php $__env->startSection('slider'); ?>

                    <div id="slider-carousel" class="carousel slide" data-ride="carousel">

                        <div class="carousel-inner">
                        <?php 
                            $i=0;
                        ?>
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $i++;
                        ?>
                            <div class="item <?php echo e($i==1 ? 'active' : ''); ?>">
                                <div class="col-sm-3">
                                    <p style="margin-top: 100px;"><?php echo e($slider->slider_desc); ?></p>
                                    
                                </div>
                                <div class="col-sm-9 image">
                                    <img src="public/uploads/slider/<?php echo e($slider->slider_image); ?>" class="girl img-responsive" alt="<?php echo e($slider->slider_desc); ?>" />
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            
                        </div>
                        <ol class="carousel-indicators">
                            <?php for($i=0; $i<$slider_active_count; $i++): ?>
                            <li data-target="#slider-carousel" data-slide-to="<?php echo e($i); ?>" class="<?php echo e($i==0 ? 'active' : ''); ?>"></li>
                            <?php endfor; ?>
                        </ol>
                        
                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Sản phẩm mới</h2>
<?php $__currentLoopData = $all_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-sm-4">
        <div class="product-image-wrapper">
            <form>
            <?php echo csrf_field(); ?>
            <div class="single-products">
                    <div class="productinfo text-center">
                    
                        <input type="hidden" value="<?php echo e($product->product_id); ?>" class="cart_product_id_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_name); ?>" class="cart_product_name_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_quantity); ?>" class="cart_product_quantity_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_image); ?>" class="cart_product_image_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_cost); ?>" class="cart_product_cost_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_price); ?>" class="cart_product_price_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_discount); ?>" class="cart_product_discount_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="1" class="cart_product_qty_<?php echo e($product->product_id); ?>">

                        <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_slug)); ?>">
                            <img src="<?php echo e(URL::to('/public/uploads/product/'.$product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="240" height="350" /><br><br>
                            <p style="font-size: 16px; text-transform: uppercase;"><?php echo e($product->product_name); ?></p>
                        <?php if($product->product_discount==0): ?>
                            <br>
                            <h2><?php echo e(number_format($product->product_price).' '.'VND'); ?></h2>
                            <img src="<?php echo e(URL::to('/public/uploads/logo/new.png')); ?>" class="new" >
                        <?php else: ?>
                            <p>Giảm: <?php echo e($product->product_discount); ?>% <span style="margin-left: 10px;"></span> <del><?php echo e(number_format($product->product_price).' '.'VND'); ?></del></p>
                            <h2><?php echo e(number_format($product->product_price - (($product->product_price*$product->product_discount)/100)).' '.'VND'); ?></h2>
                            <img src="<?php echo e(URL::to('/public/uploads/logo/sale.png')); ?>" class="new" >
                        <?php endif; ?>
                            
                        </a> 
                        <button type="button" class="btn btn-default add-to-cart" name="add-to-cart" data-id_product="<?php echo e($product->product_id); ?>"><i class="fa fa-shopping-cart"></i>Thêm vào giỏ hàng</button>
                    
                    </div>

            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    <li><a href="#" type="button" data-toggle="modal" data-target="#quickview" name="quickview" class="quickview" data-id_product="<?php echo e($product->product_id); ?>"><i class="fa fa-eye"></i>Xem nhanh</a></li>
                    <li><a href="#"><i class="fa fa-plus-square"></i>Yêu thích</a></li>
                </ul>
            </div>
            </form>
        </div>
    </div>


    <div class="modal fade" id="quickview" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title product_quickview_title" id="">
                        <span></span>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <span id="product_quickview_image"></span>
                            
                        </div>
                        <div class="col-md-7">
                        <form action="">
                         <?php echo csrf_field(); ?>
                            <div id="product_quickview_value"></div>
                            
                            <h2><span id="product_quickview_title"></span></h2>
                            <h5>Mã sp: #<span  id="product_quickview_id"></span></h5>
                            <span>
                                <h4>Giá sản phẩm: <span id="product_quickview_price"> </span> VND</h4>                               
                                
                                <div id="product_quickview_button"></div>
                                <input type="hidden" name="productid_hidden" value="">
                            <div id="beforesend_quickview"></div>
                                <h4>Mô tả sản phẩm: </h4>
                                <span id="product_quickview_desc"></span>
                                <fieldset>
                                    <span style="width: 100%;" id="product_quickview_content"></span>
                                </fieldset><br>
                             </span>   
                            
                        </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Close</button>
                    <a href="<?php echo e(URL::to('/show-cart-ajax')); ?>" type="button" class="btn btn-success">Đi tới giỏ hàng</a>
                </div>
            </div>
        </div>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--features_items-->
    <div class="pagination pagination-sm m-t-none m-b-none">
        <?php echo e($all_product->links("pagination::bootstrap-4")); ?>

    </div>

<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Sản phẩm bán chạy</h2>
<?php $__currentLoopData = $recommended_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-sm-4">
        <div class="product-image-wrapper">
            <form>
            <?php echo csrf_field(); ?>
            <div class="single-products">
                    <div class="productinfo text-center">
                    
                        <input type="hidden" value="<?php echo e($product2->product_id); ?>" class="cart_product_id_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_name); ?>" class="cart_product_name_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_quantity); ?>" class="cart_product_quantity_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_image); ?>" class="cart_product_image_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_cost); ?>" class="cart_product_cost_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_price); ?>" class="cart_product_price_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product2->product_discount); ?>" class="cart_product_discount_<?php echo e($product2->product_id); ?>">
                        <input type="hidden" value="1" class="cart_product_qty_<?php echo e($product2->product_id); ?>">

                        <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product2->product_slug)); ?>">
                            <img src="<?php echo e(URL::to('/public/uploads/product/'.$product2->product_image)); ?>" alt="<?php echo e($product2->product_name); ?>" width="240" height="350" /><br><br>
                            <p style="font-size: 16px; text-transform: uppercase;"><?php echo e($product2->product_name); ?></p>
                        <?php if($product2->product_discount==0): ?>
                            <br>
                            <h2><?php echo e(number_format($product2->product_price).' '.'VND'); ?></h2>
                        <?php else: ?>
                            <p>Giảm: <?php echo e($product2->product_discount); ?>% <span style="margin-left: 10px;"></span> <del><?php echo e(number_format($product2->product_price).' '.'VND'); ?></del></p>
                            <h2><?php echo e(number_format($product2->product_price - (($product2->product_price*$product2->product_discount)/100)).' '.'VND'); ?></h2>
                            <img src="<?php echo e(URL::to('/public/uploads/logo/sale.png')); ?>" class="new" >
                        <?php endif; ?>
                            
                        </a> 
                        <button type="button" class="btn btn-default add-to-cart" name="add-to-cart" data-id_product="<?php echo e($product2->product_id); ?>"><i class="fa fa-shopping-cart"></i>Thêm vào giỏ hàng</button>
                    
                    </div>

            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    <li><a href="#" type="button" data-toggle="modal" data-target="#quickview" name="quickview" class="quickview" data-id_product="<?php echo e($product2->product_id); ?>"><i class="fa fa-eye"></i>Xem nhanh</a></li>
                    <li><a href="#"><i class="fa fa-plus-square"></i>Yêu thích</a></li>
                </ul>
            </div>
            </form>
        </div>
    </div>


    <div class="modal fade" id="quickview" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title product_quickview_title" id="">
                        <span></span>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <span id="product_quickview_image"></span>
                            
                        </div>
                        <div class="col-md-7">
                        <form action="">
                         <?php echo csrf_field(); ?>
                            <div id="product_quickview_value"></div>
                            
                            <h2><span id="product_quickview_title"></span></h2>
                            <h5>Mã sp: #<span  id="product_quickview_id"></span></h5>
                            <span>
                                <h4>Giá sản phẩm: <span id="product_quickview_price"> </span> VND</h4>                               
                                
                                <div id="product_quickview_button"></div>
                                <input type="hidden" name="productid_hidden" value="">
                            <div id="beforesend_quickview"></div>
                                <h4>Mô tả sản phẩm: </h4>
                                <span id="product_quickview_desc"></span>
                                <fieldset>
                                    <span style="width: 100%;" id="product_quickview_content"></span>
                                </fieldset><br>
                             </span>   
                            
                        </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Close</button>
                    <a href="<?php echo e(URL::to('/show-cart-ajax')); ?>" type="button" class="btn btn-success">Đi tới giỏ hàng</a>
                </div>
            </div>
        </div>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Sản phẩm theo danh mục</h2>
    <div class="brand-tab">
        <div class="col-sm-12">
            <ul class="nav nav-tabs">
                <?php
                    $i=0;
                ?>
                <?php $__currentLoopData = $brand_product_tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tab_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;
                ?>
                    <li class="tabs_product <?php echo e($i==1 ? 'active' : ''); ?>" data-id="<?php echo e($tab_value->brand_id); ?>"><a href="#tshirt" data-toggle="tab"><?php echo e($tab_value->brand_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div id="tabs_product"></div>

        
            
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('partner'); ?>
<hr>
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Đối tác của chúng tôi</h2>

<div class="owl-carousel owl-theme">
    <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$partnerItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item">
        <a target="_blank" href="<?php echo e($partnerItem->partner_link); ?>">
            <center><h4><?php echo e($partnerItem->partner_name); ?></h4></center>
             <img src="<?php echo e(URL::to('/public/uploads/logo/'.$partnerItem->partner_image)); ?>" alt="<?php echo e($partnerItem->partner_name); ?>" width="300" height="100" />
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/home.blade.php ENDPATH**/ ?>