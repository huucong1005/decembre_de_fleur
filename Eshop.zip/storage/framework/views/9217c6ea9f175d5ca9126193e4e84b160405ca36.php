
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      <div class="col-sm-3"></div>
      <div class="col-sm-6"><center>Danh sách danh mục bài viết</center></div>
      <div class="col-sm-3">
        
        <a class="btn btn-info" href="<?php echo e(URL::to('/add-cate-post')); ?>">Thêm danh mục bài viết</a>   
        
      </div>
    </div>
    <?php
      $message = Session::get('message');
      if($message){
        echo '<br><span class="text-success">'.$message.'</span>';
        Session::put('message',null);
      }
    ?>
    <div class="table-responsive"><br>
      <table class="table table-striped b-t b-light" id="dataTableList">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>Tên danh mục</th>
            <th>Slug</th>
            <th>Hiển thị</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $list_cate_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $catePostItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
            <td><?php echo e($catePostItem->cate_post_name); ?></td>
            <td><?php echo e($catePostItem->cate_post_slug); ?></td>
            <td>
              <?php
              if($catePostItem->cate_post_status==0){
              ?>
              <a href="<?php echo e(URL::to('/active-cate-post/'.$catePostItem->cate_post_id)); ?>"><i class="fa-eye-styling fa fa-eye-slash"></i></a>
              <?php
              }else{
              ?>
              <a href="<?php echo e(URL::to('/unactive-cate-post/'.$catePostItem->cate_post_id)); ?>"><i class="fa-eye-styling fa fa-eye"></i></a>
              <?php 
              }
              ?>
            </td>
            <td>
              
              <a href="<?php echo e(URL::to('/edit-cate-post/'.$catePostItem->cate_post_id)); ?>" class="active styling-icon" ui-toggle-class=""><i class="fa fa-pencil-square-o text-success text-active"></i></a>
              
            <span style="margin: 0px 8px;"></span>
              
              <a href="<?php echo e(URL::to('/delete-cate-post/'.$catePostItem->cate_post_id)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa danh mục này ?')" ui-toggle-class=""><i class="fa fa-trash-o text-danger text"></i></a>
              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      
    </footer>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/category_post/list_cate_post.blade.php ENDPATH**/ ?>