
<?php $__env->startSection('admin_content'); ?>
<div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Cập nhật sản phẩm
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <?php $__currentLoopData = $edit_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form role="form" enctype="multipart/form-data" action="<?php echo e(URL::to('/update-product/'.$product->product_id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInput">Tên sản phẩm</label>
                                    <input type="text" name="product_name" class="form-control"  id="slug" onkeyup="ChangeToSlug();" value="<?php echo e($product->product_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Slug</label>
                                    <input type="text" name="product_slug" class="form-control" id="convert_slug" value="<?php echo e($product->product_slug); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Số lượng</label>
                                    <input type="number" name="product_quantity" class="form-control" id="exampleInput" value="<?php echo e($product->product_quantity); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Giá nhập sản phẩm</label>
                                    <input type="text" name="product_cost" class="form-control" id="exampleInput" value="<?php echo e($product->product_cost); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Giá bán sản phẩm</label>
                                    <input type="text" name="product_price" class="form-control" id="exampleInput" value="<?php echo e($product->product_price); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Hình ảnh sản phẩm</label>
                                    <input type="file" name="product_image" class="form-control image-preview" onchange="previewfile(this)" id="exampleInput">
                                    <img class="previewImg" src="<?php echo e(URL::to('public/uploads/product/'.$product->product_image)); ?>" height="150" width="120">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Mô tả sản phẩm</label>
                                    <textarea style="resize: none" rows="3" class="form-control" name="product_desc"  id="ckeditor3" ><?php echo e($product->product_desc); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Nội dung sản phẩm</label>
                                    <textarea style="resize: none" rows="6" class="form-control" name="product_content"  id="ckeditor4"><?php echo e($product->product_content); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Tags sản phẩm (dấu , để sang tags mới)</label>
                                    <input type="text" data-role="tagsinput" value="<?php echo e($product->product_tags); ?>" name="product_tags" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Danh mục sản phẩm</label>
                                    <select name="product_category" class="form-control m-bot15">  

                                    <?php $__currentLoopData = $category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($category->category_parent==0): ?>
                                            <option disabled value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endif; ?>

                                        <?php $__currentLoopData = $category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($category2->category_parent==$category->category_id): ?>
                                                <option <?php echo e($category2->category_id==$product->category_id ? 'selected': ''); ?> value="<?php echo e($category2->category_id); ?>">----<?php echo e($category2->category_name); ?></option>
                                                }
                                                }
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInput">Thương hiệu</label>
                                    <select name="product_brand" class="form-control m-bot15">
                                    <?php $__currentLoopData = $brand_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($brand->brand_id==$product->brand_id): ?>
                                        <option selected value="<?php echo e($brand->brand_id); ?>"><?php echo e($brand->brand_name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($brand->brand_id); ?>"><?php echo e($brand->brand_name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                    </select>
                                </div>
                                <button type="submit" name="update_product" class="btn btn-info">Cập nhật</button>
                                </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </section>

            </div>
<script src="<?php echo e(asset('public/backend/ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript">
    CKEDITOR.replace('ckeditor3',{
        filebrowserImageUploadUrl:"<?php echo e(url('uploads-ckeditor?_token='.csrf_token())); ?>",
        filebrowserBrowseUrl:"<?php echo e(url('file-browser?_token='.csrf_token())); ?>",
        filebrowserUploadMethod:'form'
    });
    CKEDITOR.replace('ckeditor4',{
        filebrowserImageUploadUrl:"<?php echo e(url('uploads-ckeditor?_token='.csrf_token())); ?>",
        filebrowserBrowseUrl:"<?php echo e(url('file-browser?_token='.csrf_token())); ?>",
        filebrowserUploadMethod:'form'
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/admin/product/edit_product.blade.php ENDPATH**/ ?>