
<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
<ol class="breadcrumb">
	<?php $__currentLoopData = $cate_post_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/tin-tuc')); ?>">Tin tức</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $item->cate_post_name; ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>
</nav>
<div class="features_items"><!--features_items-->
	<?php $__currentLoopData = $cate_post_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_post_name_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<h2 class="title text-center"><?php echo $cate_post_name_item->cate_post_name; ?></h2>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $cate_post_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<article class="blogpost">
	
		<div class="row"> 
			<div class="col-sm-4"> 
				<div class="blog-post-area"> 
					<a href="<?php echo e(URL::to('/tin-tuc/'.$postItem->post_slug)); ?>" target="blank" title="<?php echo e($postItem->post_name); ?>">
						<img src="<?php echo e(URL::to('/public/uploads/post/'.$postItem->post_image)); ?>"
						 class="img-responsive" style="height:16.5rem ;" alt="<?php echo e($postItem->post_name); ?>">
					</a>
				</div> 
			</div>
			<div class="col-sm-8">
				<h3 class="single-blog-post"><a href="<?php echo e(URL::to('/tin-tuc/'.$postItem->post_slug)); ?>" target="blank" title="<?php echo e($postItem->post_name); ?>"><?php echo e($postItem->post_name); ?></a></h3> 
				<div class="post-excerpt">
					<p><?php echo $postItem->post_desc; ?></p>
					<a class="btn add-to-cart pull-right" style="margin-right: 40px;"  href="<?php echo e(URL::to('/tin-tuc/'.$postItem->post_slug)); ?>">Đọc thêm...</a>
				</div>
			</div> 
		</div>
	 <hr>
		<div class="blog-sep">
		</div>
	</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
	<div class="pagination pagination-sm m-t-none m-b-none">
        <?php echo e($cate_post_by_id->links("pagination::bootstrap-4")); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/post/cate_post.blade.php ENDPATH**/ ?>