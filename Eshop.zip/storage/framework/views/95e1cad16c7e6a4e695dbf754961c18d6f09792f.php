
<?php $__env->startSection('content'); ?>
	<h2 class="title text-center">Lịch sử đặt hàng</h2>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item active" aria-current="page">Lịch sử đặt hàng</li>
  </ol>
</nav>

<div class="table-responsive"><br>
      <table class="table table-bordered b-t b-light" id="dataTableList">
        <thead>
          <tr>
            <th>Stt</th>
            <th>Mã đơn hàng</th>
            <th>Tình trạng đơn hàng</th>
            <th>Ngày đặt hàng</th>
            <th>Ngày nhận hàng</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $i=0;
          ?>
          <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $i++;
          ?>
          <tr>
            <td><i><?php echo e($i); ?></i></td>
            <td><?php echo e($order->order_code); ?></td>
            <td><?php if($order->order_status==1): ?>
                  <span class="text-info">Đơn hàng mới</span>
                <?php elseif($order->order_status==2): ?>
                  <span class="text-success">Đã xử lý</span>
                <?php else: ?>
                  <span class="text-danger">Hủy đơn hàng</span>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->created_at); ?></td>
            <td><?php echo e($order->shipping->shipping_date_revice); ?></td>
            <td>
              
              <a href="<?php echo e(URL::to('/view-order/'.$order->order_code)); ?>" class="active styling-icon" ui-toggle-class=""><i class="fa fa-eye text-success mr-2"></i>Chi tiết</a>
              
            <span style="margin: 0px 10px;"></span>
              
              <a href="<?php echo e(URL::to('/delete-order/'.$order->order_code)); ?>" class="active styling-icon" onclick="return confirm('Bạn có chắc muốn xóa danh mục này ?')" ui-toggle-class=""><i class="fa fa-power-off mr-2 text-danger "></i>Hủy</a>
              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div>
    	<div class="pagination pagination-sm m-t-none m-b-none">
        <?php echo e($all_order->links("pagination::bootstrap-4")); ?>

    </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/history_order/list_order.blade.php ENDPATH**/ ?>