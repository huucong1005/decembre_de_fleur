
<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item active" aria-current="page">Kết quả tìm kiếm: <?php echo e($keyword); ?></li>
  </ol>
</nav>
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Kết quả tìm kiếm</h2>
<?php $__currentLoopData = $search_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_slug)); ?>">
    <div class="col-sm-4">
        <div class="product-image-wrapper">
            <div class="single-products">
                    <div class="productinfo text-center">
                    <form>
                    <?php echo csrf_field(); ?>
                       <input type="hidden" value="<?php echo e($product->product_id); ?>" class="cart_product_id_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_name); ?>" class="cart_product_name_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_quantity); ?>" class="cart_product_quantity_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_image); ?>" class="cart_product_image_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_cost); ?>" class="cart_product_cost_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_price); ?>" class="cart_product_price_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_discount); ?>" class="cart_product_discount_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="1" class="cart_product_qty_<?php echo e($product->product_id); ?>">

                        <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_slug)); ?>">
                            <img src="<?php echo e(URL::to('/public/uploads/product/'.$product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="240" height="350" /><br><br>
                            <p style="font-size: 16px; text-transform: uppercase;"><?php echo e($product->product_name); ?></p>
                        <?php if($product->product_discount==0): ?>
                            <br>
                            <h2><?php echo e(number_format($product->product_price).' '.'VND'); ?></h2>
                        <?php else: ?>
                            <p>Giảm: <?php echo e($product->product_discount); ?>% <span style="margin-left: 10px;"></span> <del><?php echo e(number_format($product->product_price).' '.'VND'); ?></del></p>
                            <h2><?php echo e(number_format($product->product_price - (($product->product_price*$product->product_discount)/100)).' '.'VND'); ?></h2>
                            <img src="<?php echo e(URL::to('/public/uploads/logo/sale.png')); ?>" class="new" >
                        <?php endif; ?>
                            
                        </a> 
                        <button type="button" class="btn btn-default add-to-cart" name="add-to-cart" data-id_product="<?php echo e($product->product_id); ?>"><i class="fa fa-shopping-cart"></i>Thêm vào giỏ hàng</button>
                    </form>
                    </div>

                    
            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    <li><a href="#"><i class="fa fa-plus-square"></i>Yêu thích</a></li>
                    <li><a href="#"><i class="fa fa-plus-square"></i>So sánh</a></li>
                </ul>
            </div>
        </div>
    </div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--features_items-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eshop\resources\views/pages/product/search_result.blade.php ENDPATH**/ ?>